"""
mushroom_tuner.py
-----------------
Modul TFX Tuner untuk hyperparameter tuning otomatis menggunakan KerasTuner.
Komponen ini dijalankan SEBELUM Trainer untuk mencari kombinasi hyperparameter terbaik.

Hyperparameter yang dituning:
  - learning_rate    : kecepatan belajar optimizer Adam
  - dense_1_units    : jumlah neuron pada hidden layer pertama
  - dense_2_units    : jumlah neuron pada hidden layer kedua
  - dropout_rate     : tingkat dropout untuk regularisasi

Strategi tuning: Hyperband (lebih efisien dari RandomSearch untuk resource terbatas)
"""

import keras_tuner
import tensorflow as tf
from tensorflow.keras import layers
from tfx.components.trainer.fn_args_utils import FnArgs
from tfx.components.tuner.component import TunerFnResult
import tensorflow_transform as tft


# ─── Konstanta ──────────────────────────────────────────────────────────────

LABEL_KEY = 'class'

FEATURE_KEYS = [
    "cap-shape", "cap-surface", "cap-color", "bruises", "odor",
    "gill-attachment", "gill-spacing", "gill-size", "gill-color",
    "stalk-shape", "stalk-root", "stalk-surface-above-ring",
    "stalk-surface-below-ring", "stalk-color-above-ring",
    "stalk-color-below-ring", "veil-type", "veil-color", "ring-number",
    "ring-type", "spore-print-color", "population", "habitat"
]

NUM_EPOCHS  = 5    # epoch per trial (cukup untuk ranking, bukan final training)
BATCH_SIZE  = 64


# ─── Helper ─────────────────────────────────────────────────────────────────

def transformed_name(key: str) -> str:
    return key + "_xf"


def _gzip_reader_fn(filenames):
    return tf.data.TFRecordDataset(filenames, compression_type='GZIP')


def _input_fn(file_pattern, tf_transform_output, num_epochs, batch_size):
    """Membuat tf.data.Dataset dari TFRecord yang telah ditransformasi."""
    transformed_feature_spec = (
        tf_transform_output.transformed_feature_spec().copy()
    )
    dataset = tf.data.experimental.make_batched_features_dataset(
        file_pattern=file_pattern,
        batch_size=batch_size,
        features=transformed_feature_spec,
        reader=_gzip_reader_fn,
        num_epochs=num_epochs,
        label_key=transformed_name(LABEL_KEY),
    )
    return dataset


# ─── Model Builder ──────────────────────────────────────────────────────────

def _build_tunable_model(hp: keras_tuner.HyperParameters) -> tf.keras.Model:
    """
    Membangun model Keras dengan hyperparameter yang dapat dituning.

    Parameter yang dieksplorasi oleh KerasTuner:
      hp.Choice  ('learning_rate')  : [1e-4, 5e-4, 1e-3]
      hp.Int     ('dense_1_units')  : 32 – 256, step 32
      hp.Int     ('dense_2_units')  : 16 – 128, step 16
      hp.Float   ('dropout_rate')   : 0.1 – 0.5, step 0.1
    """
    # ── Search space ──────────────────────────────────────
    learning_rate = hp.Choice(
        'learning_rate',
        values=[1e-4, 5e-4, 1e-3],
        default=1e-3,
    )
    dense_1_units = hp.Int(
        'dense_1_units',
        min_value=32, max_value=256, step=32,
        default=64,
    )
    dense_2_units = hp.Int(
        'dense_2_units',
        min_value=16, max_value=128, step=16,
        default=32,
    )
    dropout_rate = hp.Float(
        'dropout_rate',
        min_value=0.1, max_value=0.5, step=0.1,
        default=0.2,
    )

    # ── Arsitektur ────────────────────────────────────────
    inputs = {}
    encoded_features = []

    for feature_name in FEATURE_KEYS:
        input_layer = tf.keras.Input(
            shape=(1,),
            name=transformed_name(feature_name),
            dtype=tf.float32,
        )
        inputs[transformed_name(feature_name)] = input_layer
        encoded_features.append(input_layer)

    x = layers.concatenate(encoded_features)
    x = layers.Dense(dense_1_units, activation='relu')(x)
    x = layers.Dropout(dropout_rate)(x)
    x = layers.Dense(dense_2_units, activation='relu')(x)
    x = layers.Dropout(dropout_rate)(x)
    output = layers.Dense(1, activation='sigmoid')(x)

    model = tf.keras.Model(inputs=inputs, outputs=output)
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=learning_rate),
        loss='binary_crossentropy',
        metrics=['accuracy', tf.keras.metrics.AUC(name='auc')],
    )
    return model


# ─── Entry Point TFX ────────────────────────────────────────────────────────

def tuner_fn(fn_args: FnArgs) -> TunerFnResult:
    """
    Fungsi utama yang dipanggil oleh komponen TFX Tuner.

    Mengembalikan TunerFnResult berisi:
      - tuner     : instance KerasTuner yang telah dikonfigurasi
      - fit_kwargs: argumen yang akan diteruskan ke tuner.search()
    """
    tf_transform_output = tft.TFTransformOutput(fn_args.transform_graph_path)

    # ── Dataset ───────────────────────────────────────────
    train_dataset = _input_fn(
        fn_args.train_files,
        tf_transform_output,
        num_epochs=NUM_EPOCHS,
        batch_size=BATCH_SIZE,
    )
    eval_dataset = _input_fn(
        fn_args.eval_files,
        tf_transform_output,
        num_epochs=NUM_EPOCHS,
        batch_size=BATCH_SIZE,
    )

    # ── Tuner: Hyperband ──────────────────────────────────
    # Hyperband lebih efisien dari RandomSearch karena mengalokasikan
    # resource secara adaptif (trial buruk dihentikan lebih awal).
    tuner = keras_tuner.Hyperband(
        hypermodel=_build_tunable_model,
        objective=keras_tuner.Objective('val_auc', direction='max'),
        max_epochs=NUM_EPOCHS,
        factor=3,
        directory=fn_args.working_dir,
        project_name='mushroom_hyperband_tuning',
        overwrite=True,
    )

    return TunerFnResult(
        tuner=tuner,
        fit_kwargs={
            'x': train_dataset,
            'validation_data': eval_dataset,
            'steps_per_epoch': fn_args.train_steps,
            'validation_steps': fn_args.eval_steps,
        },
    )
